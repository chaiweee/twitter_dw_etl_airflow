# jwtf

JSON Web Token Functions

This library provides JWT parsing and validation functions

Supports;

* Verify
* RS256
* RS384
* RS512
* HS256
* HS384
* HS512
* ES256
* ES384
* ES512
